# coding=utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
# 设置monkey运行参数
apkpackagename = "xxxx"
seed=300
throttle=1000
whitelist=""
blacklist="xxxx"
eventcount="1000"
loglevel="INFO"
testaccount="monkeytestlfc"
testpwd = "Qq123123"
demoaccount="monkeydemoandroid"
demopwd = "Qq123123"
#demoaccount="zxx"
#demopwd = "Qq123123"
jenkins_server_url="xxxx"
job_name= "xxxx"
env='demo'