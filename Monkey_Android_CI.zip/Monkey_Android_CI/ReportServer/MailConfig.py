# coding=utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
# 设置服务器，用户名、口令以及邮箱的后缀
mail_host = "smtp.partner.outlook.cn"
mail_port=25
mail_user = "xxxxxx"
mail_pass = "xxxxxx"
mail_postfix = "xxxx"
debuglist = ['xxxx','xxxx']
receiverslist = ['xxxx','xxxxx']
