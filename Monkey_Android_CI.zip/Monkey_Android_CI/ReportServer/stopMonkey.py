# coding=utf-8
import logger,os,re
from report import *
dev='0216029b21df2403'
def stopmonkey():
    '''
    停止Monkey
    :return:
    '''
    # 利用管道打印内容
    try:

        grep_cmd = "adb -s %s shell ps | grep monkey" % dev
        pipe = os.popen(grep_cmd)
        result = pipe.read()
        if result == '':
            logger.log_info('monekey进程不存在')
        else:
            logger.log_info('monekey进程存在')
            pid = result.split()[1]
            # kill monkey进程
            stop_cmd = "adb -s %s shell kill %s" % (dev, pid)
            os.system(stop_cmd)
    except Exception as e:
        logger.log_error('stopmonkey异常: ' + str(e))
def getlogcat(packagename,logcatpath):
    '''
    获取logcat日志中所有日志
    :return:返回保存logcat的文件地址
    '''
    #logcatpath = self.db.logdir + "/" + time.strftime("%Y%m%d%H%M%S") + "_logcat.log"
    # 定义logcat文件保存地址
    cmd = "adb -s 0216029b21df2403 logcat -d -v time *:W | grep %s >%s" % (packagename,logcatpath)
    # 获取logcat日志
    os.popen(cmd)
    time.sleep(2)
    return logcatpath

def parse_logcat_log(logcatpath):
    #cmd = 'adb logcat -v time *:W | grep com.chinaway.android.truck.manager > %s' % logcatpath
    #os.popen(cmd)
    number = 1
    fetalnum = 0
    fetal = ErrorMsg("FATAL", fetalnum, '')
    error_list_logcat = []
    try:
        f = open(logcatpath, "r")
        lines = f.readlines()

        if len(lines) == 0:
            logger.log_info("扫描%s路径的log日志为空,将删除" % logcatpath)
            os.system('rm -rf %s' % logcatpath)
        else:
            logger.log_info("扫描%s路径的log日志不为空" % logcatpath)

            for line in lines:
                if (re.findall("FATAL", line)):
                    fetalnum += 1
                    fetal.error_count = fetalnum
                    fetal.error_desc = fetal.error_desc + "logcat日志第%s行" % number + ' , ' + "错误原因:%s" % line + '<br>'
                number += 1
                f.close()

            error_list_logcat.append(fetal)
            #error_list.append(emANR)
            #error_list.append(emNoResponse)
            #error_list.append(emError)
            #error_list.append(emException)

    except Exception,e:
        logger.log_error(e.message)
    print error_list_logcat
    return error_list_logcat
if __name__ == '__main__':
    #stopmonkey()
    path = '/Users/truckmanager_test/Desktop/2.log'
    getlogcat=getlogcat('xxxxx',path)
    parse_logcat_log(getlogcat)